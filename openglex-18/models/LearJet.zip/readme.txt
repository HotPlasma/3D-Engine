-- 3dvia.com   --

The zip file learjet.3ds.zip contains the following files :
- readme.txt
- learjet.3ds
- learjet.jpg

I've added a .obj file - converted by Maya


-- Model information --

Model Name : learjet
Author : 
Publisher : sprotz

You can view this model here :
http://www.3dvia.com/content/C4A676FACCDEF0C2
More models about this author :
http://www.3dvia.com/sprotz


-- Attached license --

A license is attached to the learjet model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
